import { useNavigate } from "react-router-dom";
import { formatTime, type Conversation } from "../../lib/chat";
import { useWorkspace } from "../../store/workspace";

/** 按活跃时间分组：今天 / 昨天 / 近 7 天 / 更早。 */
function groupOf(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "更早";
  const now = new Date();
  const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const t = d.getTime();
  if (t >= startToday) return "今天";
  if (t >= startToday - 86400000) return "昨天";
  if (t >= startToday - 6 * 86400000) return "近 7 天";
  return "更早";
}

const ORDER = ["今天", "昨天", "近 7 天", "更早"];

/** 左导航的会话列表：日期分组 + 当前会话高亮（主色圆点）。 */
export default function ConversationGroups() {
  const navigate = useNavigate();
  const conversations = useWorkspace((s) => s.conversations);
  const activeId = useWorkspace((s) => s.activeId);
  const running = useWorkspace((s) => s.running);
  const open = useWorkspace((s) => s.open);

  const groups = ORDER.map((label) => ({
    label,
    items: conversations.filter((c) => groupOf(c.updatedAt) === label),
  })).filter((g) => g.items.length > 0);

  const select = (c: Conversation) => {
    void open(c.id);
    navigate("/chat");
  };

  if (conversations.length === 0) {
    return <p className="px-gutter-sm py-gutter-md font-label text-label-sm text-light-outline dark:text-dark-outline">还没有历史会话（近 20 天）</p>;
  }

  return (
    <div className="flex flex-col gap-gutter-md">
      {groups.map((g) => (
        <div key={g.label} className="flex flex-col gap-gutter-xs">
          <span className="px-gutter-sm font-label text-label-sm text-light-outline dark:text-dark-outline">{g.label}</span>
          {g.items.map((c) => {
            const active = c.id === activeId;
            return (
              <button
                key={c.id}
                type="button"
                title={c.title}
                disabled={running}
                onClick={() => select(c)}
                className={`group flex w-full items-center gap-gutter-sm rounded px-gutter-sm py-1.5 text-left transition-colors duration-state-change disabled:opacity-60 ${
                  active
                    ? "bg-light-surface-container dark:bg-dark-surface-container"
                    : "hover:bg-light-surface-container-high dark:hover:bg-dark-surface-container-high"
                }`}
              >
                <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${active ? "bg-light-primary dark:bg-dark-primary" : "bg-transparent"}`} />
                <span className="min-w-0 flex-1 truncate font-label text-label-md text-light-on-surface dark:text-dark-on-surface">{c.title}</span>
                <span className="shrink-0 font-mono text-mono-sm text-light-outline tabular-nums dark:text-dark-outline">{formatTime(c.updatedAt)}</span>
              </button>
            );
          })}
        </div>
      ))}
    </div>
  );
}