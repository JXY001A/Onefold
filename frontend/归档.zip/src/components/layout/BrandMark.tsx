import clsx from "clsx";

/** 品牌标识：设计稿的折叠六边形 SVG，置于圆角小盒中。 */
export default function BrandMark({ className }: { className?: string }) {
  return (
    <span
      className={clsx(
        "inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-sm border",
        "border-light-outline-variant bg-light-surface-container dark:border-dark-outline-variant dark:bg-dark-surface-container",
        className,
      )}
    >
      <svg width="15" height="15" viewBox="0 0 14 14" fill="none" className="text-light-primary dark:text-dark-primary">
        <path d="M2.5 3.5L7 2L11.5 3.5V10.5L7 12L2.5 10.5V3.5Z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" />
        <path d="M7 2V12" stroke="currentColor" strokeWidth="1.2" />
      </svg>
    </span>
  );
}