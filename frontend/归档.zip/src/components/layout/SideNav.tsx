import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { canUseAdmin } from "../../lib/roles";
import { visibleNav } from "../../lib/nav";
import { useWorkspace } from "../../store/workspace";
import Icon from "../ui/Icon";
import Soon from "../ui/Soon";
import BrandMark from "./BrandMark";
import ConversationGroups from "./ConversationGroups";
import NavUser from "./NavUser";
import NavRail from "./NavRail";

/** 展开式左导航（240px）：品牌 / 新建 / 检索 / 模块 / 会话分组 / 身份。 */
function ExpandedNav() {
  const { me } = useAuth();
  const navigate = useNavigate();
  const toggleNav = useWorkspace((s) => s.toggleNav);
  const startNew = useWorkspace((s) => s.startNew);
  const running = useWorkspace((s) => s.running);
  const items = visibleNav(me?.role, canUseAdmin(me?.role));

  const newResearch = () => {
    startNew();
    navigate("/chat");
  };

  return (
    <aside className="flex w-[240px] shrink-0 flex-col border-r border-light-outline-variant bg-light-surface-container-low py-gutter-md dark:border-dark-outline-variant dark:bg-dark-surface-container-low">
      {/* 品牌 + 收起 */}
      <div className="flex items-center gap-gutter-sm px-gutter-md">
        <BrandMark />
        <div className="min-w-0 flex-1">
          <p className="font-headline text-title-md text-light-on-surface dark:text-dark-on-surface">Onefold</p>
          <p className="font-label text-label-sm text-light-outline dark:text-dark-outline">研究工作区</p>
        </div>
        <button type="button" onClick={toggleNav} aria-label="收起导航" title="收起导航" className="inline-flex h-8 w-8 items-center justify-center rounded text-light-on-surface-variant hover:bg-light-surface-container-high dark:text-dark-on-surface-variant dark:hover:bg-dark-surface-container-high">
          <Icon name="dock_to_left" size={18} />
        </button>
      </div>

      {/* 新建研究 */}
      <div className="px-gutter-md pt-gutter-md">
        <button
          type="button"
          onClick={newResearch}
          disabled={running}
          className="flex w-full items-center justify-center gap-1.5 rounded border border-light-primary bg-light-primary px-gutter-md py-2 font-label text-label-md text-light-on-primary transition-colors duration-state-change hover:opacity-90 disabled:opacity-50 dark:border-dark-primary dark:bg-dark-primary dark:text-dark-on-primary"
        >
          <Icon name="add" size={17} />
          新建研究
        </button>
      </div>

      {/* 快速检索（尚无后端，禁用提示） */}
      <div className="px-gutter-md pt-gutter-sm">
        <Soon tip="快速检索随后开放" className="w-full">
          <span className="flex w-full items-center gap-gutter-sm rounded border border-light-outline-variant bg-light-surface px-gutter-sm py-2 font-label text-label-md text-light-on-surface-variant dark:border-dark-outline-variant dark:bg-dark-surface dark:text-dark-on-surface-variant">
            <Icon name="search" size={17} />
            <span className="flex-1 text-left">快速检索</span>
            <span className="font-mono text-mono-sm text-light-outline dark:text-dark-outline">⌘K</span>
          </span>
        </Soon>
      </div>

      <div className="mx-gutter-md my-gutter-md border-t border-light-outline-variant dark:border-dark-outline-variant" />

      {/* 模块导航 */}
      <nav className="flex flex-col gap-gutter-xs px-gutter-md">
        {items.map((n) => (
          <NavLink
            key={n.to}
            to={n.to}
            className={({ isActive }) =>
              `flex items-center gap-gutter-sm rounded px-gutter-sm py-2 font-label text-label-md transition-colors duration-state-change ${
                isActive
                  ? "bg-light-surface-container-high text-light-primary dark:bg-dark-surface-container-high dark:text-dark-primary"
                  : "text-light-on-surface-variant hover:bg-light-surface-container-high dark:text-dark-on-surface-variant dark:hover:bg-dark-surface-container-high"
              }`
            }
          >
            <Icon name={n.icon} size={18} />
            {n.label}
          </NavLink>
        ))}
      </nav>

      <div className="mx-gutter-md my-gutter-md border-t border-light-outline-variant dark:border-dark-outline-variant" />

      {/* 会话分组（可滚动） */}
      <div className="min-h-0 flex-1 overflow-y-auto px-gutter-md pb-gutter-md">
        <ConversationGroups />
      </div>

      <div className="px-gutter-md">
        <NavUser />
      </div>
    </aside>
  );
}

/** 左导航入口：按折叠状态在展开式与图标栏之间切换。 */
export default function SideNav() {
  const collapsed = useWorkspace((s) => s.navCollapsed);
  return collapsed ? <NavRail /> : <ExpandedNav />;
}