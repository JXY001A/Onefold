import { useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import type { ChatMessage } from "../../lib/chat";
import RetrievalStatus from "./RetrievalStatus";
import ToolDrawer from "./ToolDrawer";
import ToolStatus from "./ToolStatus";

/** 单条消息：用户问题用卡片，助手报告按编辑式 Markdown 排版（含表格/任务列表）。 */
export default function MessageItem({ message }: { message: ChatMessage }) {
  const [open, setOpen] = useState(false);
  const isUser = message.role === "user";
  const tools = message.tools ?? [];

  if (isUser) {
    return (
      <div className="rounded-md border border-light-outline-variant bg-light-surface px-gutter-md py-gutter-sm dark:border-dark-outline-variant dark:bg-dark-surface">
        <span className="font-label text-label-sm text-light-outline dark:text-dark-outline">研究问题</span>
        <p className="mt-0.5 whitespace-pre-wrap font-body text-body-md text-light-on-surface dark:text-dark-on-surface">{message.content}</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-gutter-md">
      <div className="flex items-center justify-between gap-gutter-sm">
        <span className="font-label text-label-sm text-light-primary dark:text-dark-primary">归一 · 研究报告</span>
        {tools.length > 0 && <ToolStatus tools={tools} onClick={() => setOpen(true)} />}
      </div>

      <RetrievalStatus tools={tools} />

      <div className="markdown font-body text-body-md text-light-on-surface dark:text-dark-on-surface">
        {/* singleTilde:false —— 否则「5~12℃」这类区间会被 GFM 当成删除线吞掉 */}
        <ReactMarkdown remarkPlugins={[[remarkGfm, { singleTilde: false }]]}>{message.content}</ReactMarkdown>
        {message.content === "" && <span className="of-caret" />}
      </div>

      {open && tools.length > 0 && <ToolDrawer tools={tools} onClose={() => setOpen(false)} />}
    </div>
  );
}