import { useNavigate } from "react-router-dom";
import { useWorkspace, type InspectorTab } from "../../store/workspace";
import Icon from "../ui/Icon";
import Soon from "../ui/Soon";
import InspectorTools from "./InspectorTools";

const TABS: { key: InspectorTab; label: string; icon: string }[] = [
  { key: "sources", label: "来源", icon: "article" },
  { key: "memory", label: "记忆", icon: "psychology" },
  { key: "tools", label: "工具", icon: "travel_explore" },
  { key: "docs", label: "文档", icon: "folder_open" },
];

/** 占位面板：尚无后端支撑的功能，保留可见但禁用并提示随后开放。 */
function SoonPanel({ icon, title, desc }: { icon: string; title: string; desc: string }) {
  return (
    <div className="flex flex-col items-center gap-gutter-sm px-gutter-md py-section text-center">
      <Soon tip="随后开放">
        <span className="inline-flex h-12 w-12 items-center justify-center rounded-md border border-light-outline-variant bg-light-surface-container dark:border-dark-outline-variant dark:bg-dark-surface-container">
          <Icon name={icon} size={24} className="text-light-on-surface-variant dark:text-dark-on-surface-variant" />
        </span>
      </Soon>
      <p className="font-headline text-title-md text-light-on-surface dark:text-dark-on-surface">{title}</p>
      <p className="font-body text-body-sm text-light-on-surface-variant dark:text-dark-on-surface-variant">{desc}</p>
      <span className="rounded-sm bg-light-warning-container px-gutter-sm py-0.5 font-label text-label-sm text-light-on-warning-container dark:bg-dark-warning-container dark:text-dark-on-warning-container">随后开放</span>
    </div>
  );
}

/** 右侧来源检查器：来源 / 记忆 / 工具 / 文档四个标签，可展开到 440px。 */
export default function SourceInspector() {
  const navigate = useNavigate();
  const expanded = useWorkspace((s) => s.inspectorExpanded);
  const tab = useWorkspace((s) => s.inspectorTab);
  const messages = useWorkspace((s) => s.messages);
  const toggleExpanded = useWorkspace((s) => s.toggleExpanded);
  const setInspectorOpen = useWorkspace((s) => s.setInspectorOpen);
  const setTab = useWorkspace((s) => s.setInspectorTab);

  const tools = messages.flatMap((m) => m.tools ?? []);

  return (
    <aside className={`fixed inset-y-0 right-0 z-40 flex shrink-0 flex-col border-l border-light-outline-variant bg-light-surface-container-low shadow-2xl xl:static xl:z-auto xl:shadow-none dark:border-dark-outline-variant dark:bg-dark-surface-container-low ${expanded ? "w-[440px] max-w-[92vw]" : "w-[320px] max-w-[92vw]"}`}>
      <header className="flex items-center justify-between gap-gutter-sm px-gutter-md py-gutter-sm">
        <h2 className="font-headline text-title-md text-light-on-surface dark:text-dark-on-surface">来源检查器</h2>
        <div className="flex items-center gap-gutter-xs">
          <button type="button" onClick={toggleExpanded} title={expanded ? "还原宽度" : "展开检查器"} className="inline-flex h-8 w-8 items-center justify-center rounded text-light-on-surface-variant hover:bg-light-surface-container-high dark:text-dark-on-surface-variant dark:hover:bg-dark-surface-container-high">
            <Icon name={expanded ? "close_fullscreen" : "open_in_full"} size={17} />
          </button>
          <button type="button" onClick={() => setInspectorOpen(false)} title="收起来源" className="inline-flex h-8 w-8 items-center justify-center rounded text-light-on-surface-variant hover:bg-light-surface-container-high dark:text-dark-on-surface-variant dark:hover:bg-dark-surface-container-high">
            <Icon name="close" size={17} />
          </button>
        </div>
      </header>

      <div className="grid grid-cols-4 border-b border-light-outline-variant dark:border-dark-outline-variant">
        {TABS.map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => setTab(t.key)}
            className={`-mb-px flex items-center justify-center gap-1 border-b-2 px-1 py-gutter-sm font-label text-label-sm transition-colors duration-state-change ${
              tab === t.key
                ? "border-light-primary text-light-primary dark:border-dark-primary dark:text-dark-primary"
                : "border-transparent text-light-on-surface-variant hover:text-light-on-surface dark:text-dark-on-surface-variant dark:hover:text-dark-on-surface"
            }`}
          >
            <Icon name={t.icon} size={15} />
            {t.label}
          </button>
        ))}
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto">
        {tab === "sources" && <SoonPanel icon="article" title="引用来源对照" desc="报告引用的页码锚点与原文片段对照，将随检索来源能力一起开放。" />}
        {tab === "tools" && <InspectorTools tools={tools} />}
        {tab === "memory" && (
          <div className="flex flex-col items-center gap-gutter-sm px-gutter-md py-section text-center">
            <Icon name="psychology" size={28} className="text-light-primary dark:text-dark-primary" />
            <p className="font-body text-body-sm text-light-on-surface-variant dark:text-dark-on-surface-variant">跨会话保存的偏好与背景，可在研究记忆页查看与编辑。</p>
            <button type="button" onClick={() => navigate("/memory")} className="rounded-sm border border-light-outline-variant px-gutter-md py-1.5 font-label text-label-md text-light-on-surface hover:border-light-primary dark:border-dark-outline-variant dark:text-dark-on-surface dark:hover:border-dark-primary">前往研究记忆</button>
          </div>
        )}
        {tab === "docs" && (
          <div className="flex flex-col items-center gap-gutter-sm px-gutter-md py-section text-center">
            <Icon name="folder_open" size={28} className="text-light-primary dark:text-dark-primary" />
            <p className="font-body text-body-sm text-light-on-surface-variant dark:text-dark-on-surface-variant">个人与公共知识库文档，可在知识库页上传与管理。</p>
            <button type="button" onClick={() => navigate("/documents")} className="rounded-sm border border-light-outline-variant px-gutter-md py-1.5 font-label text-label-md text-light-on-surface hover:border-light-primary dark:border-dark-outline-variant dark:text-dark-on-surface dark:hover:border-dark-primary">前往知识库</button>
          </div>
        )}
      </div>
    </aside>
  );
}