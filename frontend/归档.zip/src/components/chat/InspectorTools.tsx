import type { ToolRun } from "../../lib/chat";
import { clip, toolLabel, toolTarget } from "../../lib/tools";
import Icon from "../ui/Icon";

/** 检查器「工具」面板：把本轮所有搜索/抓取汇总成可点击的来源清单。 */
export default function InspectorTools({ tools }: { tools: ToolRun[] }) {
  if (tools.length === 0) {
    return (
      <div className="flex flex-col items-center gap-gutter-sm px-gutter-md py-section text-center">
        <Icon name="travel_explore" size={28} className="text-light-outline dark:text-dark-outline" />
        <p className="font-body text-body-sm text-light-on-surface-variant dark:text-dark-on-surface-variant">本轮还没有工具调用。发送问题后，联网搜索与读取的网页会列在这里。</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-gutter-md px-gutter-md py-gutter-md">
      {tools.map((t) => {
        const items = t.data?.items ?? [];
        return (
          <section key={t.id} className="flex flex-col gap-gutter-sm">
            <div className="flex items-center gap-1.5 font-label text-label-sm">
              <Icon name={t.status === "error" ? "error" : "check_circle"} size={15} className={t.status === "error" ? "text-light-warning dark:text-dark-warning" : "text-light-primary dark:text-dark-primary"} />
              <span className="text-light-on-surface dark:text-dark-on-surface">{toolLabel(t.name)}</span>
              <span className="min-w-0 truncate font-mono text-mono-sm text-light-outline dark:text-dark-outline">{clip(toolTarget(t.args, t.data), 24)}</span>
            </div>

            {t.data?.kind === "fetch" && (
              <a href={t.data.url} target="_blank" rel="noreferrer" className="rounded border border-light-outline-variant p-gutter-sm transition-colors duration-state-change hover:border-light-primary dark:border-dark-outline-variant dark:hover:border-dark-primary">
                <p className="font-label text-label-md text-light-on-surface dark:text-dark-on-surface">{t.data.title}</p>
                <p className="mt-0.5 truncate font-mono text-mono-sm text-light-outline dark:text-dark-outline">{t.data.url}</p>
              </a>
            )}

            {items.map((it, i) => (
              <a key={it.url || `${i}-${it.title}`} href={it.url || undefined} target="_blank" rel="noreferrer" className="rounded border border-light-outline-variant p-gutter-sm transition-colors duration-state-change hover:border-light-primary dark:border-dark-outline-variant dark:hover:border-dark-primary">
                <p className="font-label text-label-md text-light-on-surface dark:text-dark-on-surface">{it.title}</p>
                <p className="mt-0.5 truncate font-mono text-mono-sm text-light-outline dark:text-dark-outline">{it.site || it.url}</p>
                {it.snippet && <p className="mt-1 line-clamp-2 font-body text-body-sm text-light-on-surface-variant dark:text-dark-on-surface-variant">{it.snippet}</p>}
              </a>
            ))}
          </section>
        );
      })}
    </div>
  );
}