import { useWorkspace } from "../../store/workspace";
import Icon from "../ui/Icon";

const btn =
  "inline-flex items-center gap-1.5 rounded-sm border border-light-outline-variant bg-light-surface px-gutter-sm py-1.5 font-label text-label-sm text-light-on-surface-variant transition-colors duration-state-change hover:text-light-on-surface dark:border-dark-outline-variant dark:bg-dark-surface dark:text-dark-on-surface-variant dark:hover:text-dark-on-surface";

/** 工作区顶栏：研究标题 + 专注模式 / 来源检查器开关。吸附顶部。 */
export default function WorkspaceHeader() {
  const activeId = useWorkspace((s) => s.activeId);
  const conversations = useWorkspace((s) => s.conversations);
  const focusMode = useWorkspace((s) => s.focusMode);
  const inspectorOpen = useWorkspace((s) => s.inspectorOpen);
  const setFocusMode = useWorkspace((s) => s.setFocusMode);
  const setInspectorOpen = useWorkspace((s) => s.setInspectorOpen);

  const title = conversations.find((c) => c.id === activeId)?.title ?? "新建研究";

  const toggleInspector = () => {
    if (focusMode) {
      setFocusMode(false);
      setInspectorOpen(true);
    } else {
      setInspectorOpen(!inspectorOpen);
    }
  };

  return (
    <header className="sticky top-0 z-10 flex items-center justify-between gap-gutter-md border-b border-light-outline-variant bg-light-background px-gutter-xl py-gutter-md dark:border-dark-outline-variant dark:bg-dark-background">
      <div className="flex min-w-0 items-center gap-gutter-md">
        <h1 className="truncate font-headline text-headline-lg text-light-on-surface dark:text-dark-on-surface">{title}</h1>
        {focusMode && (
          <span className="shrink-0 rounded-sm bg-light-primary-container px-gutter-sm py-0.5 font-label text-label-sm text-light-on-primary-container dark:bg-dark-primary-container dark:text-dark-on-primary-container">
            专注阅读模式
          </span>
        )}
      </div>

      <div className="flex shrink-0 items-center gap-gutter-sm">
        <button type="button" className={btn} onClick={() => setFocusMode(!focusMode)} title={focusMode ? "退出专注模式" : "专注阅读模式"}>
          <Icon name={focusMode ? "close_fullscreen" : "center_focus_strong"} size={15} />
          {focusMode ? "退出专注" : "专注阅读"}
        </button>
        <button type="button" className={btn} onClick={toggleInspector} title="来源检查器">
          <Icon name="dock_to_left" size={15} />
          {inspectorOpen && !focusMode ? "收起来源" : "展开来源"}
        </button>
      </div>
    </header>
  );
}