import type { ToolRun } from "../../lib/chat";
import { clip, hitCount, toolLabel, toolTarget } from "../../lib/tools";
import Icon from "../ui/Icon";

/** 检索/工具状态：可折叠明细，列出本轮真实工具调用（设计稿 retrieval-status 样式）。 */
export default function RetrievalStatus({ tools }: { tools: ToolRun[] }) {
  if (tools.length === 0) return null;
  const running = tools.some((t) => t.status === "running");
  const hits = tools.reduce((n, t) => n + hitCount(t.data), 0);

  return (
    <details open className="group rounded border border-light-outline-variant bg-light-surface dark:border-dark-outline-variant dark:bg-dark-surface">
      <summary className="flex cursor-pointer list-none items-center gap-gutter-sm px-gutter-md py-gutter-sm font-label text-label-md text-light-on-surface-variant dark:text-dark-on-surface-variant [&::-webkit-details-marker]:hidden">
        <span className={`h-1.5 w-1.5 rounded-full ${running ? "animate-pulse bg-light-warning dark:bg-dark-warning" : "bg-light-primary dark:bg-dark-primary"}`} />
        <span className="flex-1">
          {running ? "正在检索与读取…" : `${tools.length} 次工具调用`}
          {hits > 0 && <span className="font-mono text-mono-sm text-light-outline dark:text-dark-outline"> · {hits} 个网页</span>}
        </span>
        <Icon name="expand_more" size={18} className="transition-transform duration-state-change group-open:rotate-180" />
      </summary>
      <div className="grid grid-cols-1 gap-gutter-sm border-t border-light-outline-variant px-gutter-md py-gutter-sm sm:grid-cols-2 dark:border-dark-outline-variant">
        {tools.map((t) => (
          <div key={t.id} className="flex items-center gap-1.5 font-label text-label-sm text-light-on-surface-variant dark:text-dark-on-surface-variant">
            <Icon
              name={t.status === "running" ? "progress_activity" : t.status === "error" ? "error" : "check_circle"}
              size={15}
              className={t.status === "error" ? "text-light-warning dark:text-dark-warning" : "text-light-primary dark:text-dark-primary"}
            />
            <span className="shrink-0 text-light-on-surface dark:text-dark-on-surface">{toolLabel(t.name)}</span>
            <span className="min-w-0 truncate font-mono text-mono-sm text-light-outline dark:text-dark-outline">{clip(toolTarget(t.args, t.data), 28)}</span>
          </div>
        ))}
      </div>
    </details>
  );
}