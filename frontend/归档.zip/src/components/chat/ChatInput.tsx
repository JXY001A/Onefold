import Icon from "../ui/Icon";
import Soon from "../ui/Soon";

type Props = {
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
  onStop: () => void;
  running: boolean;
  disabled?: boolean;
};

const ghost =
  "inline-flex items-center gap-1 rounded-sm px-gutter-sm py-1 font-label text-label-sm text-light-on-surface-variant dark:text-dark-on-surface-variant";

/** 研究输入区：Enter 发送 / Shift+Enter 换行；范围、附加文档、@引用尚待开放。 */
export default function ChatInput({ value, onChange, onSend, onStop, running, disabled = false }: Props) {
  return (
    <div className="shrink-0 border-t border-light-outline-variant bg-light-background px-gutter-xl py-gutter-md dark:border-dark-outline-variant dark:bg-dark-background">
      <div className="mx-auto w-full max-w-[800px] rounded-md border border-light-outline-variant bg-light-surface px-gutter-md py-gutter-sm transition-colors duration-state-change focus-within:border-light-primary dark:border-dark-outline-variant dark:bg-dark-surface dark:focus-within:border-dark-primary">
        <textarea
          value={value}
          rows={2}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              onSend();
            }
          }}
          disabled={running || disabled}
          placeholder={disabled ? "正在准备会话…" : "输入研究问题，或粘贴链接 / 上传文档…"}
          className="w-full resize-none border-0 bg-transparent p-0 font-body text-body-sm text-light-on-surface placeholder:text-light-outline focus:ring-0 disabled:opacity-60 dark:text-dark-on-surface dark:placeholder:text-dark-outline"
        />

        <div className="mt-gutter-sm flex items-center justify-between gap-gutter-sm">
          <div className="flex items-center gap-gutter-xs">
            <Soon tip="检索范围随后开放">
              <span className={ghost}>
                <Icon name="tune" size={15} />
                范围
              </span>
            </Soon>
            <Soon tip="附加文档随后开放">
              <span className={ghost}>
                <Icon name="attach_file" size={15} />
                附加文档
              </span>
            </Soon>
            <Soon tip="@ 引用知识库随后开放">
              <span className={ghost}>
                <Icon name="alternate_email" size={15} />
                引用知识库
              </span>
            </Soon>
          </div>

          {running ? (
            <button type="button" onClick={onStop} className="inline-flex shrink-0 items-center gap-1 rounded-sm border border-light-outline-variant px-gutter-md py-1.5 font-label text-label-md text-light-on-surface dark:border-dark-outline-variant dark:text-dark-on-surface">
              <Icon name="stop" size={15} />
              停止
            </button>
          ) : (
            <button
              type="button"
              onClick={onSend}
              disabled={disabled || !value.trim()}
              className="inline-flex shrink-0 items-center gap-1 rounded-sm bg-light-primary px-gutter-md py-1.5 font-label text-label-md text-light-on-primary transition-opacity duration-state-change hover:opacity-90 disabled:opacity-40 dark:bg-dark-primary dark:text-dark-on-primary"
            >
              <Icon name="arrow_upward" size={15} />
              发送
            </button>
          )}
        </div>
      </div>
    </div>
  );
}