import { useEffect, useState } from "react";
import ChatInput from "../components/chat/ChatInput";
import MessageList from "../components/chat/MessageList";
import QuotaBar from "../components/chat/QuotaBar";
import SourceInspector from "../components/chat/SourceInspector";
import WorkspaceHeader from "../components/chat/WorkspaceHeader";
import { useAuth } from "../context/AuthContext";
import { useChatStream } from "../hooks/useChatStream";
import { useWorkspace } from "../store/workspace";

/** 研究工作区：中央报告画布 + 右侧来源检查器，会话/消息状态来自全局 store。 */
export default function Chat() {
  const [input, setInput] = useState("");
  const { me, refresh: refreshMe } = useAuth();

  const messages = useWorkspace((s) => s.messages);
  const activeId = useWorkspace((s) => s.activeId);
  const ready = useWorkspace((s) => s.ready);
  const loading = useWorkspace((s) => s.loading);
  const storeError = useWorkspace((s) => s.error);
  const focusMode = useWorkspace((s) => s.focusMode);
  const inspectorOpen = useWorkspace((s) => s.inspectorOpen);
  const setMessages = useWorkspace((s) => s.setMessages);
  const setActiveId = useWorkspace((s) => s.setActiveId);
  const setRunning = useWorkspace((s) => s.setRunning);
  const refresh = useWorkspace((s) => s.refresh);

  const { running, status, error, quotaExceeded, resetQuota, send, abort } = useChatStream({
    setMessages,
    conversationId: activeId,
    onConversation: setActiveId,
    onRoundDone: () => {
      void refresh();
      void refreshMe();
    },
  });

  // 把流式运行状态同步到全局，左导航据此禁用切换
  useEffect(() => {
    setRunning(running);
  }, [running, setRunning]);

  const handleSend = () => {
    const text = input.trim();
    if (!text) return;
    setInput("");
    resetQuota();
    void send(text);
  };

  const exhausted = quotaExceeded || (me?.quota ? me.quota.used >= me.quota.limit : false);

  return (
    <div className="flex h-full min-w-0">
      <section className="flex min-w-0 flex-1 flex-col">
        <WorkspaceHeader />

        <div className="min-h-0 flex-1">
          <MessageList
            messages={messages}
            status={loading ? "加载历史…" : status}
            error={storeError ?? error}
            onPick={setInput}
            focus={focusMode}
          />
        </div>

        {me?.quota && (
          <div className="px-gutter-xl pb-gutter-sm">
            <QuotaBar used={me.quota.used} limit={me.quota.limit} exhausted={exhausted} />
          </div>
        )}

        <ChatInput
          value={input}
          onChange={setInput}
          onSend={handleSend}
          onStop={abort}
          running={running}
          disabled={!ready || exhausted}
        />
      </section>

      {inspectorOpen && !focusMode && (
        <>
          {/* 窄屏下检查器为浮层，点击遮罩收起 */}
          <div className="fixed inset-0 z-30 bg-black/40 xl:hidden" onClick={() => useWorkspace.getState().setInspectorOpen(false)} />
          <SourceInspector />
        </>
      )}
    </div>
  );
}